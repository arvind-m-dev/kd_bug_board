export const STATUSES = [
  "NEW",
  "VALIDATING",
  "VALIDATED",
  "READY_FOR_ASSIGNMENT",
  "ASSIGNED",
  "IN_PROGRESS",
  "RECHECK",
  "RESOLVED",
  "NEEDS_INFORMATION",
  "REOPENED",
  "DUPLICATE",
  "NOT_A_BUG",
  "WONT_FIX",
] as const;
export type Status = (typeof STATUSES)[number];
export type Role = "admin" | "reporter" | "qa" | "developer" | "member";
export const OPEN_STATUSES: readonly Status[] = ["NEW", "VALIDATED", "ASSIGNED", "IN_PROGRESS"];
export type Bug = {
  id: string;
  title: string;
  status: Status;
  priority: string;
  severity: string;
  description: string;
  steps: string[];
  expected: string;
  actual: string;
  assigneeId: string | null;
  comments: string[];
  evidence: { name: string; url: string }[];
};
export function counts(bugs: Bug[]) {
  return {
    total: bugs.length,
    open: bugs.filter((b) => OPEN_STATUSES.includes(b.status)).length,
    unassigned: bugs.filter((b) => b.assigneeId === null).length,
    recheck: bugs.filter((b) => b.status === "RECHECK").length,
  };
}
export function filterBugs(bugs: Bug[], filter: string, query = "") {
  return bugs.filter(
    (b) =>
      (filter === "all" ||
        (filter === "open"
          ? OPEN_STATUSES.includes(b.status)
          : filter === "unassigned"
            ? b.assigneeId === null
            : b.status === filter)) &&
      `${b.id} ${b.title} ${b.description}`.toLowerCase().includes(query.toLowerCase()),
  );
}
const transitions: Record<Status, readonly Status[]> = {
  NEW: ["VALIDATING", "NEEDS_INFORMATION", "DUPLICATE", "NOT_A_BUG"],
  VALIDATING: ["VALIDATED", "NEEDS_INFORMATION", "DUPLICATE", "NOT_A_BUG", "WONT_FIX"],
  VALIDATED: ["READY_FOR_ASSIGNMENT"],
  READY_FOR_ASSIGNMENT: ["ASSIGNED"],
  ASSIGNED: ["IN_PROGRESS", "NOT_A_BUG", "DUPLICATE", "WONT_FIX"],
  IN_PROGRESS: ["RECHECK", "NEEDS_INFORMATION", "NOT_A_BUG", "DUPLICATE", "WONT_FIX"],
  RECHECK: ["RESOLVED", "REOPENED"],
  RESOLVED: ["REOPENED"],
  NEEDS_INFORMATION: ["VALIDATING", "IN_PROGRESS"],
  REOPENED: ["IN_PROGRESS", "ASSIGNED", "NOT_A_BUG", "DUPLICATE", "WONT_FIX"],
  DUPLICATE: ["VALIDATING"],
  NOT_A_BUG: ["VALIDATING"],
  WONT_FIX: ["VALIDATING"],
};
export function canTransition(role: Role, from: Status, to: Status, verified = false) {
  if (!transitions[from].includes(to)) return false;
  if (to === "RESOLVED") return role === "qa" && from === "RECHECK" && verified;
  if (role === "reporter" || role === "member") return false;
  if (role === "developer")
    return (
      ((from === "ASSIGNED" || from === "REOPENED") && to === "IN_PROGRESS") ||
      (from === "IN_PROGRESS" && to === "RECHECK") ||
      (["ASSIGNED", "IN_PROGRESS", "REOPENED"].includes(from) &&
        ["NOT_A_BUG", "DUPLICATE", "WONT_FIX"].includes(to))
    );
  return true;
}
export function exportMarkdown(bugs: Bug[]) {
  return bugs
    .map(
      (b) =>
        `# ${b.id}: ${b.title}\n\n- Status: ${b.status}\n- Priority: ${b.priority}\n- Severity: ${b.severity}\n\n## Description\n${b.description}\n\n## Steps to reproduce\n${b.steps.map((s, i) => `${i + 1}. ${s}`).join("\n")}\n\n## Expected result\n${b.expected}\n\n## Actual result\n${b.actual}\n\n## Comments\n${b.comments.join("\n\n") || "None"}\n\n## Evidence\n${b.evidence.map((e) => `[${e.name}](${e.url})`).join("\n") || "None"}`,
    )
    .join("\n\n---\n\n");
}
// Link previews use one brand title and the dashboard image: shared links land unsigned on /login, and private page details should not leak.
const SHARE_TITLE = "Futurist Global Bug Board";
const SHARE_DESCRIPTION =
  "Report, assign and verify bugs in one shared QA workspace for Futurist Global teams.";
const OG_IMAGE = `${import.meta.env["VITE_SITE_URL"] ?? ""}/og-image.jpg`;
export function pageHead(title: string, description: string) {
  return {
    meta: [
      { title: `${title} · Futurist Global Bug Board` },
      { name: "description", content: description },
      { property: "og:title", content: SHARE_TITLE },
      { property: "og:description", content: SHARE_DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:image", content: OG_IMAGE },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Futurist Global Bug Board dashboard" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: SHARE_TITLE },
      { name: "twitter:description", content: SHARE_DESCRIPTION },
      { name: "twitter:image", content: OG_IMAGE },
      { name: "robots", content: "noindex, nofollow" },
      { name: "referrer", content: "no-referrer" },
    ],
  };
}
