async function key() {
  const raw = process.env["BUGFLOW_PORTAL_ENCRYPTION_KEY"];
  if (!raw) throw new Error("Secure portal copying is not configured.");
  return crypto.subtle.importKey(
    "raw",
    await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)),
    { name: "AES-GCM" },
    false,
    ["encrypt", "decrypt"],
  );
}
export async function encryptPortal(token: string) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(
    await crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      await key(),
      new TextEncoder().encode(token),
    ),
  );
  return btoa(String.fromCharCode(...iv, ...ct));
}
export async function decryptPortal(value: string) {
  const bytes = Uint8Array.from(atob(value), (c) => c.charCodeAt(0));
  return new TextDecoder().decode(
    await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: bytes.slice(0, 12) },
      await key(),
      bytes.slice(12),
    ),
  );
}
